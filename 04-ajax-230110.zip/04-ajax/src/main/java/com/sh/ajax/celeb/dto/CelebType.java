package com.sh.ajax.celeb.dto;

public enum CelebType {
	
	ACTOR,
	SINGER,
	MODEL,
	COMEDIAN,
	ENTERTAINER;

}
